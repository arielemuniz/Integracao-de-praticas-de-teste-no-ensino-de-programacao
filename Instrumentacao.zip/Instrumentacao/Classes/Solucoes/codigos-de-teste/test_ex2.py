import unittest
from ex2 import Pessoa

class TestPessoa(unittest.TestCase):

    def setUp(self):
        nome = "João"
        idade = 19
        peso = 60
        altura = 160
        self.pessoa = Pessoa(nome, idade, peso, altura)


    def test_envelhecer_menor_21_idade(self):
        self.pessoa.envelhecer()
        resultadoEsperadoIdade = 20
        self.assertEqual(resultadoEsperadoIdade,self.pessoa.idade)

    def test_envelhecer_menor_21_altura(self):
        self.pessoa.envelhecer()
        resultadoEsperadoAltura = 160.5
        self.assertEqual(resultadoEsperadoAltura, self.pessoa.altura)

    def test_envelhecer_maior_21_idade(self):
        self.pessoa.envelhecer()
        self.pessoa.envelhecer()
        resultadoEsperadoIdade = 21
        self.assertEqual(resultadoEsperadoIdade, self.pessoa.idade)

    def test_envelhecer_maior_21_altura(self):
        self.pessoa.envelhecer()
        self.pessoa.envelhecer()
        resultadoEsperadoAltura = 160.5
        self.assertEqual(resultadoEsperadoAltura, self.pessoa.altura)

    def test_engordar_menor_que_zero(self):
        self.assertEqual("Valor inválido", self.pessoa.engordar(-0.1))

    def test_engordar_igual_zero(self):
        self.pessoa.engordar(0)
        resultadoEsperadoPeso = 60
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_engordar_limite_superior_zero(self):
        self.pessoa.engordar(0.1)
        resultadoEsperadoPeso = 60.1
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_engordar_maior_que_zero(self):
        self.pessoa.engordar(5)
        resultadoEsperadoPeso = 65
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_engordar_menor_que_dez(self):
        self.pessoa.engordar(9.9)
        resultadoEsperadoPeso = 69.9
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_engordar_igual_dez(self):
        self.pessoa.engordar(10)
        resultadoEsperadoPeso = 70
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_engordar_maior_que_dez(self):
        self.assertEqual("Valor inválido", self.pessoa.engordar(10.1))

    def test_emagrecer_menor_que_zero(self):
        self.assertEqual("Valor inválido", self.pessoa.emagrecer(-0.1))

    def test_emagrecer_igual_zero(self):
        self.pessoa.emagrecer(0)
        resultadoEsperadoPeso = 60
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_emagrecer_limite_superior_zero(self):
        self.pessoa.emagrecer(0.1)
        resultadoEsperadoPeso = 59.9
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_emagrecer_maior_que_zero(self):
        self.pessoa.emagrecer(5)
        resultadoEsperadoPeso = 55
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_emagrecer_menor_que_dez(self):
        self.pessoa.emagrecer(9.9)
        resultadoEsperadoPeso = 50.1
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_emagrecer_igual_dez(self):
        self.pessoa.emagrecer(10)
        resultadoEsperadoPeso = 50
        self.assertEqual(resultadoEsperadoPeso, self.pessoa.peso)

    def test_emagrecer_maior_que_dez(self):
        self.assertEqual("Valor inválido", self.pessoa.emagrecer(10.1))

    def test_crescer_menor_que_zero(self):
        self.assertEqual("Valor inválido", self.pessoa.crescer(-0.1))

    def test_crescer_igual_zero(self):
        self.pessoa.crescer(0)
        resultadoEsperadoAltura = 160
        self.assertEqual(resultadoEsperadoAltura, self.pessoa.altura)

    def test_crescer_limite_superior_zero(self):
        self.pessoa.crescer(0.1)
        resultadoEsperadoAltura = 160.1
        self.assertEqual(resultadoEsperadoAltura, self.pessoa.altura)

    def test_crescer_maior_que_zero(self):
        self.pessoa.crescer(10)
        resultadoEsperadoAltura = 170
        self.assertEqual(resultadoEsperadoAltura, self.pessoa.altura)

    def test_crescer_menor_que_quinze(self):
        self.pessoa.crescer(14.9)
        resultadoEsperadoAltura = 174.9
        self.assertEqual(resultadoEsperadoAltura, self.pessoa.altura)

    def test_crescer_igual_quinze(self):
        self.pessoa.crescer(15)
        resultadoEsperadoAltura = 175
        self.assertEqual(resultadoEsperadoAltura, self.pessoa.altura)


    def test_crescer_maior_que_quinze(self):
        self.assertEqual("Valor inválido", self.pessoa.crescer(15.1))


if __name__ == '__main__':
    unittest.main()
