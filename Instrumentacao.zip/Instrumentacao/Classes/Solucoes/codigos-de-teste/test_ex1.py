import unittest
from ex1 import PesquisaAnonima

class TestPesquisaAnonima(unittest.TestCase):

    def setUp(self):
        self.pesquisa = PesquisaAnonima("Qual linguagem você aprendeu a falar primeiro?")


    def test_adicionar_resposta_vazia(self):
        resposta_vazia = ""
        resultadoEsperado = "Resposta inválida"
        self.assertEqual(resultadoEsperado, self.pesquisa.adicionarResposta(resposta_vazia))


    def test_adicionar_uma_resposta(self):
        resposta = "Português"
        self.pesquisa.adicionarResposta(resposta)
        resultadoEsperado = "Resultados: - Português"
        self.assertIn(resultadoEsperado, self.pesquisa.exibirResultados())


    def test_exibir_resultados(self):
        respostas = ["Português", "Inglês", "Mandarim"]
        self.pesquisa.adicionarResposta(respostas[0])
        self.pesquisa.adicionarResposta(respostas[1])
        self.pesquisa.adicionarResposta(respostas[2])
        resultadoEsperado = "Resultados: - Português - Inglês - Mandarim"

        self.assertEqual(resultadoEsperado, self.pesquisa.exibirResultados())

    def test_exibir_resultado_vazio(self):
        resultadoEsperado = "Resultados:"
        self.assertEqual(resultadoEsperado, self.pesquisa.exibirResultados())


if __name__ == '__main__':
    unittest.main()
