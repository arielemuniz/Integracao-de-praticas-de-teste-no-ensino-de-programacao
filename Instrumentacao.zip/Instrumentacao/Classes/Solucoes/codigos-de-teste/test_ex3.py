import unittest
from ex3 import Quadrado

class TestQuadrado(unittest.TestCase):
        
        def setUp(self):
                lado = 5
                self.quadrado = Quadrado(lado)
        
        def test_mudaValor_lado_negativo(self):
                lado = -0.1
                self.assertEqual("Lado com valor inválido", self.quadrado.mudarValorLado(lado))

        def test_mudaValor_lado_zero(self):
                lado = 0
                self.assertEqual("Lado com valor inválido", self.quadrado.mudarValorLado(lado))

        def test_mudaValor_lado_limite_superior(self):
                lado = 0.1
                self.quadrado.mudarValorLado(lado)
                self.assertEqual(lado, self.quadrado.lado)

        def test_mudaValor_lado_maior_que_zero(self):
                lado = 10.5
                self.quadrado.mudarValorLado(lado)
                self.assertEqual(lado, self.quadrado.lado)

        def test_retornaValor(self):
                self.assertEqual(self.quadrado.lado, self.quadrado.retornarValorLado())

        def test_calculaArea(self):
                resultadoEsperado = 25
                self.assertEqual(resultadoEsperado, self.quadrado.calcularArea())

if __name__ == '__main__':
        unittest.main()