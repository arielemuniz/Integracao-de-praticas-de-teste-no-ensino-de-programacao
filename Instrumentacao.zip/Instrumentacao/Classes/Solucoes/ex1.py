class PesquisaAnonima():

    def __init__(self, pergunta):
        self.pergunta = pergunta
        self.respostas = []


    def adicionarResposta(self, novaResposta):
        if novaResposta == "":
            return "Resposta inválida"
        self.respostas.append(novaResposta)


    def exibirResultados(self):
        resultados = "Resultados:"
        for resposta in self.respostas:
            resultados+= ' - ' + resposta
        return resultados


