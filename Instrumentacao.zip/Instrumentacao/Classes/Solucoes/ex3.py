class Quadrado():

    def __init__(self, lado):
        self.lado = lado

    def mudarValorLado(self, novoValorLado):
        if novoValorLado <= 0:
            return "Lado com valor inválido"
        self.lado = novoValorLado

    def retornarValorLado(self):
        return self.lado

    def calcularArea(self):
        return self.lado * self.lado