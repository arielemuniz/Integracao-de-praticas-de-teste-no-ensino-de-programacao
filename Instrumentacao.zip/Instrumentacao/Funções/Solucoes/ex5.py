def converteHora(h, m):
    if h == 0 and 0 <= m < 60:
        return saida(h+12, m, 'A')
    elif 0 < h < 12 and 0 <= m < 60:
        return saida(h, m, 'A')
    elif h == 12 and 0 <= m < 60:
        return saida(h, m, 'P')
    elif 12 <= h < 24 and 0 <= m < 60:
        return saida(h-12, m, 'P')
    else:
        return 'Valor inválido'


def saida(h, m, notacao):
    h = str(h)
    m = str(m)
    if len(m) == 1:
        m = '0'+ m
    if notacao == 'A':
        return h + ':' + m + ' A.M'
    elif notacao == 'P':
        return h + ':' + m + ' P.M'


