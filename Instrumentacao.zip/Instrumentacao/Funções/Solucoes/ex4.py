def somaImposto(taxaImposto, custo):
    if taxaImposto < 0:
        return "Taxa de imposto inválida"
    if custo < 0:
        return "Custo inválido"
    return round(((0.01*taxaImposto)*custo) + custo,2)
