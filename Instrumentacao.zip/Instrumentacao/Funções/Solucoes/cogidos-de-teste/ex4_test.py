import unittest
from ex4 import somaImposto

class SomaImpostoTestCase(unittest.TestCase):

    def test_taxaimposto_valor_negativo(self):
        taxaimposto = -0.1
        custo = 20.5
        self.assertEqual("Taxa de imposto inválida", somaImposto(taxaimposto, custo))

    def test_taxaimposto_igual_zero(self):
        taxaimposto = 0
        custo = 20.5
        resultadoEsperado = 20.5
        self.assertEqual(resultadoEsperado, somaImposto(taxaimposto, custo))

    def test_taxaimposto_limite_superior(self):
        taxaimposto = 0.1
        custo = 20.5
        resultadoEsperado = 20.52
        self.assertEqual(resultadoEsperado, somaImposto(taxaimposto, custo))

    def test_taxaimposto_maior_que_zero(self):
        taxaimposto = 50
        custo = 20.5
        resultadoEsperado = 30.75
        self.assertEqual(resultadoEsperado, somaImposto(taxaimposto, custo))

    def test_custo_valor_negativo(self):
        taxaimposto = 50
        custo = -0.1
        self.assertEqual("Custo inválido", somaImposto(taxaimposto, custo))

    def test_custo_igual_zero(self):
        taxaimposto = 50
        custo = 0
        resultadoEsperado = 0
        self.assertEqual(resultadoEsperado, somaImposto(taxaimposto, custo))

    def test_custo_limite_superior(self):
        taxaimposto = 50
        custo = 0.1
        resultadoEsperado = 0.15
        self.assertEqual(resultadoEsperado, somaImposto(taxaimposto, custo))

    def test_custo_maior_que_zero(self):
        taxaimposto = 50
        custo = 200
        resultadoEsperado = 300
        self.assertEqual(resultadoEsperado, somaImposto(taxaimposto, custo))


if __name__ == '__main__':
    unittest.main()
