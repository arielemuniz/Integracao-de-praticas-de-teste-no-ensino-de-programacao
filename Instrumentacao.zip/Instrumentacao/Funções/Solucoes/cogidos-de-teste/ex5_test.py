import unittest
from ex5 import converteHora


class converteHoraTestCase(unittest.TestCase):

    def test_hora_invalida(self):
        hora = -1
        hora2 = 24
        minuto = 30
        self.assertEqual("Valor inválido", converteHora(hora, minuto), "Hora com valor negativo")
        self.assertEqual("Valor inválido", converteHora(hora2, minuto), "Hora igual a 24")

    def test_hora_igual_zero(self):
        hora = 0
        minuto = 0
        self.assertEqual("12:00 A.M", converteHora(hora, minuto))

    def test_hora_maior_zero_menor_doze(self):
        hora2 = 1
        hora3 = 5
        minuto = 30
        self.assertEqual("1:30 A.M", converteHora(hora2, minuto), "Hora com valor de 1")
        self.assertEqual("5:30 A.M", converteHora(hora3, minuto), "Hora com valor de 5")

    def test_hora_valor_limite_inferior_doze(self):
        hora = 11
        minuto = 59
        self.assertEqual("11:59 A.M", converteHora(hora, minuto))


    def test_hora_igual_doze(self):
        hora = 12
        minuto = 00
        self.assertEqual("12:00 P.M", converteHora(hora, minuto))

    def test_hora_maior_que_doze(self):
        hora1 = 13
        hora2 = 17
        hora3 = 23
        minuto = 30
        self.assertEqual("1:30 P.M", converteHora(hora1, minuto), "Hora igual a 13")
        self.assertEqual("5:30 P.M", converteHora(hora2, minuto), "Hora igual a 17")
        self.assertEqual("11:30 P.M", converteHora(hora3, minuto), "Hora igual a 23")

    def test_minuto_invalido(self):
        hora = 20
        minuto1 = -1
        minuto2 = 60
        self.assertEqual("Valor inválido", converteHora(hora, minuto1), "Minuto com valor negativo")
        self.assertEqual("Valor inválido", converteHora(hora, minuto2), "Minuto igual a 60")

    def test_minuto_igual_zero(self):
        hora = 20
        minuto = 0
        self.assertEqual("8:00 P.M", converteHora(hora, minuto))

    def test_minuto_maior_que_zero(self):
        hora = 23
        minuto1 = 1
        minuto2 = 30
        minuto3 = 59
        self.assertEqual("11:01 P.M", converteHora(hora, minuto1), "Minuto igual a 1")
        self.assertEqual("11:30 P.M", converteHora(hora, minuto2), "Minuto igual a 30")
        self.assertEqual("11:59 P.M", converteHora(hora, minuto3), "Minuto igual a 59")


if __name__ == '__main__':
    unittest.main()
