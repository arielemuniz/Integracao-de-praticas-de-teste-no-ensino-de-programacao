import unittest
from ex6 import valorPagamento


class valorPagamentoTestCase(unittest.TestCase):

    def test_prestacao_invalida(self):
        prestacao1 = -1
        prestacao2 = 0
        dias = 5
        self.assertEqual("Valor inválido",valorPagamento(prestacao1, dias), "Prestação com valor negativo")
        self.assertEqual("Valor inválido", valorPagamento(prestacao2, dias), "Prestação com valor igual a 0")

    def test_prestacao_maior_que_zero(self):
        prestacao1 = 0.1
        prestacao2 = 200
        dias = 5
        resultadoEsperado1 = 0.10
        resultadoEsperado2 = 207.03
        self.assertEqual(resultadoEsperado1, valorPagamento(prestacao1, dias), "Prestação com valor igual a 0.1")
        self.assertEqual(resultadoEsperado2, valorPagamento(prestacao2, dias), "Prestação com valor igual a 200")

    def test_dias_invalido(self):
        prestacao = 200
        dias = -1
        self.assertEqual("Valor inválido", valorPagamento(prestacao, dias))

    def test_dias_igual_zero(self):
        prestacao = 200
        dias = 0
        resultadoEsperado = 200
        self.assertEqual(resultadoEsperado, valorPagamento(prestacao, dias))

    def test_dias_maior_que_zero(self):
        prestacao = 200
        dias = 1
        resultadoEsperado = 206.21
        self.assertEqual(resultadoEsperado, valorPagamento(prestacao, dias))


if __name__ == '__main__':
    unittest.main()
