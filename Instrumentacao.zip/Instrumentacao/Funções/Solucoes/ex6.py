def valorPagamento(prestacao, dias):
    if prestacao <= 0 or dias < 0:
        return "Valor inválido"
    if dias == 0:
        return prestacao
    else:
        prestacao = prestacao * 1.03
        return round(prestacao * ((1 + 0.001) ** dias), 2)



